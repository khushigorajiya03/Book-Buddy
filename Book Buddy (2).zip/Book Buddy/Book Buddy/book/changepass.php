<?php
	
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$email = trim($_POST['email']);
	$newPassword = trim($_POST['newPassword']);
	$confirmPassword = trim($_POST['confirmPassword']);

	if($email == "" || $newPassword == "" || $confirmPassword == ""){
		echo "Name or Pass is empty!";
		exit;
	}

	if($newPassword != $confirmPassword){
		echo "password and Confirm password not match";
		exit;
	}

    $newPass = md5($newPassword);
	// update from db
    //UPDATE users SET `password` = '1234' WHERE `email` = 'i@gmail.com';
	$query = "UPDATE users SET `password` = '$newPass' WHERE `email` = '$email'";
	
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Email id not exist";
		exit;
	}
	
	if(isset($conn)) {mysqli_close($conn);}
	header("Location: index.php");
?>