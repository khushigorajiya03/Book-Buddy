<?php
	session_start();
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$query = "SELECT * FROM category";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't retrieve data " . mysqli_error($conn);
		exit;
	}
	if(mysqli_num_rows($result) == 0){
		echo "Empty Category ! Something wrong! check again";
		exit;
	}

	$title = "List Of Category";
	require "./template/header.php";
?>
	<p class="lead">List of Category</p>
	<ul>
		<?php 
			while($row = mysqli_fetch_assoc($result)){
				?>
					<li>
						<span class="badge"><?php //echo getbookcount($row['id']); ?></span>
					    <a href="bookpercat.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a>
					</li>
				<?php
			}
		?>
		<center>
	<form method="post" class="login-button" action="books.php">
			
			<div class="input-book .btn">
					<button type="submit"   class="btn btn-primary ">List full of books</button>	
			</div>
		
		</center>
<?php
	mysqli_close($conn);
?>