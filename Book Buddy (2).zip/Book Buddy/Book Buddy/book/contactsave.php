<?php
	
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$name = trim($_POST['name']);
	$email = trim($_POST['email']);
	$description = $_POST['description'];

	if($name == "" || $email == "" || $description == ""){
		echo "Field can't be empty!";
		exit;
	}

	$query = "INSERT INTO contact (`name`, `email`, `description`) VALUES ('$name', '$email', '$description')";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Data can't save";
		exit;
	}
	
	if(isset($conn)) {mysqli_close($conn);}
	header("Location: contact.php");
?>