<?php
	session_start();
	require_once "./functions/database_functions.php";
	$conn = db_connect();

	$query = "SELECT * FROM author ORDER BY authorid";
	$result = mysqli_query($conn, $query);
	if(!$result){
		echo "Can't retrieve data " . mysqli_error($conn);
		exit;
	}
	if(mysqli_num_rows($result) == 0){
		echo "Empty author ! Something wrong! check again";
		exit;
	}

	$title = "List Of Auth";
	require "./template/header.php";
?>
	<p class="lead">List of Author</p>
	

	<?php 

		while($row = mysqli_fetch_assoc($result)){
			$count = 0; 
			$query = "SELECT authorid FROM author";
			$result2 = mysqli_query($conn, $query);
			if(!$result2){
				echo "Can't retrieve data " . mysqli_error($conn);
				exit;
			}
			while ($authInBook = mysqli_fetch_assoc($result2)){
				if($authInBook['authorid'] == $row['authorid']){
					$count++;
				}
			}
			
		
	?>
	
		<li>
			<span class="badge"><?php echo $count; ?></span>
		    <a href="bookPerPub1.php?authid=<?php echo $row['authorid']; ?>"><?php echo $row['authorname']; ?></a>
		</li>
	<?php } ?>
		<center>
	<form method="post" class="login-button" action="books.php">
			
			<div class="input-book .btn">
					<button type="submit"   class="btn btn-primary ">List full of books</button>	
			</div>
		
		</center>
	
<?php
	mysqli_close($conn);
	
?>