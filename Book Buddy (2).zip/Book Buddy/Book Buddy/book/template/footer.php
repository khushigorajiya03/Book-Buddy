      	<hr>

      	<footer>
        	<div class="text-muted pull-left">
            	
        	</div>
        	<div class="text-muted pull-right">
          		<a href="admin.php">Admin Login</a> 
        	</div>
      	</footer>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="./bootstrap/js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>