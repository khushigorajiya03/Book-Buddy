<?php
  $title = "Contact";
  session_start();
  require_once "./template/header.php";
  $email = $_SESSION['email'];
  $query = "";
?>
    <div class="row">
        
    </div>