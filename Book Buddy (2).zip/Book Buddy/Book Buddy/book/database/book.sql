-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2022 at 10:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `pass` varchar(40) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `pass`) VALUES
('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997');

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `authorid` int(10) UNSIGNED NOT NULL,
  `authorname` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`authorid`, `authorname`) VALUES
(7, 'Shravya'),
(10, 'Matthew Rulli'),
(11, 'Muskan Jha'),
(12, 'Dr. Joseph Murphy'),
(13, 'R. Chandan Deshmukh'),
(14, 'Ajay K Pandey'),
(15, 'Alex Michaelides'),
(16, 'Lisa Jewell'),
(17, 'Nikhil Raj'),
(18, 'Swami Nikhilananda'),
(19, 'Wonder House Books'),
(20, 'Walter Isaacson'),
(21, 'Patrick Fischler'),
(22, 'Nishant K Baxi'),
(23, 'D. G. Torrens'),
(24, 'Emily Giffin'),
(25, 'Krishna Reddy'),
(26, 'T. Christian Miller'),
(27, 'Ernesto Patino'),
(28, 'Dan Cushman'),
(29, 'Derra Nicole Sabo'),
(30, 'khurram murad'),
(31, 'Francisco Szekely'),
(32, 'Gertrude Marie'),
(33, 'Umair Riaz'),
(34, 'Ernest A. Lommatsch'),
(35, 'Michael Teitelbaum');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_isbn` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `book_title` varchar(60) COLLATE latin1_general_ci DEFAULT NULL,
  `book_author` varchar(60) COLLATE latin1_general_ci DEFAULT NULL,
  `book_image` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `book_descr` text COLLATE latin1_general_ci DEFAULT NULL,
  `book_price` decimal(6,2) NOT NULL,
  `publisherid` int(10) UNSIGNED NOT NULL,
  `authorid` int(10) UNSIGNED NOT NULL,
  `category` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_isbn`, `book_title`, `book_author`, `book_image`, `book_descr`, `book_price`, `publisherid`, `authorid`, `category`) VALUES
('0143423320', 'Myth = Mithya: Decoding Hindu Mythology', 'Devdutt Pattanaik', 'Mithya Decoding Hindu Mythology.png', 'A brilliant pocket-sized handbook on Hindu mythology penned in English by an Indian author Devdutt Pattanaik. The book Myth = Mithya: Decoding Hindu Mythology has fabulously conceptualized as a story based on Shiva and Shankara. The book has also decoded the Phallic Symbol and also demonstrates the story about the man who was a woman and another queer story from Hindu lore.\r\n\r\nThe story has a lucid and provocative introduction named Ancient Hindu seers knew myth as mithya. Pattanaik has explained that it would be arrogant to presume that the ancients actually assumed in \"virgin births, flying horses, talking serpents, gods with six heads and demons with eight arms\". These are symbolic presentations of the thoughts of truths that need to be conveyed. The concepts in the book are inspired by revolutionary art, the establishment of empires, etc. The book is segmented into three parts decanted into the Brahma-Saraswati, Vishnu-Lakshmi, and Shiva-Shakti. It features these gods or goddesses in simple and attractive prose and the reference has been taken from the Vedas and Puranas', '217.00', 8, 8, 1),
('0262035995', 'Beyond the triple bottom line', 'Francisco Szekely', 'Beyond the triple bottom line.jpg', 'Many recent books make the case for businesses to become more sustainable, but few explain the specifics. In this book, Francisco Szekely and Zahir Dossa offer a pragmatic new business model for sustainability that extends beyond the traditional framework of the triple bottom line, describing eight steps that range from exploring a vision and establishing a strategy to implementing the strategy and promoting innovation.\r\n\r\nSzekely and Dossa argue that businesses and organizations need to move away from the business case for sustainability toward a sustainable business model. That is, businesses should go beyond the usual short-term focus on minimizing harm while maximizing profits. Instead, businesses on the path to sustainability should, from the start, focus on addressing a societal need and view profitability not as an end but as a means to support the sustainable organization.', '550.00', 31, 31, 10),
('0345546903', 'One & only', 'Emily Giffin', 'One & only.jpg', 'Thirty-three-year-old Shea Rigsby has spent her entire life in Walker, Texas—a small college town that lives and dies by football, a passion she unabashedly shares. Raised alongside her best friend, Lucy, the daughter of Walker’s legendary head coach, Clive Carr, Shea was too devoted to her hometown team to leave. Instead she stayed in Walker for college, even taking a job in the university athletic department after graduation, where she has remained for more than a decade.\r\n \r\nBut when an unexpected tragedy strikes the tight-knit Walker community, Shea’s comfortable world is upended, and she begins to wonder if the life she’s chosen is really enough for her. As she finally gives up her safety net to set out on an unexpected path, Shea discovers unsettling truths about the people and things she has always trusted most—and is forced to confront her deepest desires, fears, and secrets.', '400.00', 24, 24, 6),
('0708946747', 'Shadow of the stranger', 'Ernesto Patino', 'Shadow of the stranger.jpg', 'When recently married Tess Bellairs joined her husband and his newfound family in Toronto, she was shocked by major changes in his personality. Was Johnnie\'s erratic behavior a result of the attentions of his many-times-removed -- and strikingly beautiful -- cousin, Olivia?', '500.00', 27, 27, 8),
('073642198X', 'Sleeping beauty', 'Michael Teitelbaum', 'Seeping beauty.jpg', 'With the help of three good fairies, Princess Aurora grows up safe and protected from the evil Maleficent. But everything changes when she meets Prince Phillip and falls in love. Disney Princess fans ages 2 to 5 will love this Little Golden Book retelling of Disney Sleeping Beauty!', '300.00', 34, 35, 5),
('078621032X', 'Blood on the Saddle', 'Dan Cushman', 'Blood on the Saddle.jpg', 'For years the Button family has been defending their reserve from annexation by the ruthless Omaha & Montana Cattle Company, and now, with Billy Button accused of murder, the ranch\'s existance depends upon the skills of brilliant defense attorney Thomas F. Boe.', '400.00', 28, 28, 8),
('0953676803', 'Early morning hours', 'khurram murad', 'Early morning hours.jpg', 'How are we to become true believers who seek God\'s good pleasure? How are we to become mindful of God, to be thankful or worshipful? How are we to control our anger and pride? How are we to follow the example of the Prophet Muhammad (peace be upon him)? This inspirational book of wise advice answers these questions and guides us toward the spiritual life.\r\n\r\nKhurram Murad (1932–1996) was the director general of The Islamic Foundation, United Kingdom, and a renowned teacher who spent 40 years in the spiritual teaching and training of thousands of young Muslim people around the globe. He has published more than 20 works in English and Urdu.', '250.00', 30, 30, 9),
('1409181634', 'The Silent Patient: The record-breaking', 'Alex Michaelides', 'silent patint.jpg', 'WITH OVER THREE MILLION COPIES SOLD, read the Sunday Times and No.1 New York Times bestselling, record-breaking thriller that everyone is talking about - soon to be a major film.\r\nThe perfect thriller AJ FINN\r\nTerrific - THE TIMES Crime Book of the Month\r\nSmart, sophisticated suspense- LEE CHILD\r\nCompelling - OBSERVER\r\nAbsolutely brilliant- STEPHEN FRY\r\nA totally original psychological mystery - DAVID BALDACCI\r\nOne of the best thrillers I have read this year- CARA HUNTER\r\nThe pace and finesse of a master- BBC CULTURE\r\nAlicia Berenson lived a seemingly perfect life until one day six years ago.When she shot her husband in the head five times.\r\nSince then she has not spoken a single word.It is time to find out why.\r\nTHE SILENT PATIENT is the gripping must-read thriller of the year - perfect for fans of THE FAMILY UPSTAIRS by Lisa Jewell, BLOOD ORANGE by Harriet Tyce and PLAYING NICE by JP Delaney.', '320.00', 16, 15, 3),
('1499748949', 'Tears of endurance', 'D. G. Torrens', 'tears of endurance.jpg', 'A secret can tear you apart … or bind you forever. For Arianna Ferria, a satisfying and challenging life as an art gallery owner takes an unexpected turn into burning romance when she falls for the handsome and successful Ben Fielding. Soon, their relationship blossoms into more than she could ever imagine. But when a black secret comes crashing down around them, their love faces the ultimate test as they come to grips with a tragic fate that will change the course of their lives forever … Tears of Endurance', '230.00', 23, 23, 6),
('1661848532', 'All I Ever Want Is You: A True Love Story', 'Nikhil Raj', 'all i want', 'Raj and Alisha meet at a family party and fall for each other, later they realise they love each other, but until then, they have drifted apart due to some family drama. ‘All I Ever Want Is You is the story of finding love, finding passion, and separation. This is a story that defines love, a journey that leads you to love your loved ones and yourself.', '250.00', 18, 17, 3),
('1786090074', 'Unbelievable', 'T. Christian Miller', 'Unbelievable.jpg', 'She said she was raped.\r\nPolice said she lied.\r\nShe was made to retract the report – but the nightmare only got worse.\r\n\r\nOn 11 August 2008, eighteen-year-old Marie reported that a masked man had broken into her home and raped her. Within days, police – and even those closest to Marie – became suspicious of her story. Confronted by these minor inconsistencies and doubt, Marie broke down and said her story was a lie. The police charged her with making a false report.\r\n\r\nTwo years later, Colorado detective Stacy Galbraith was assigned to a case of sexual assault. It bore an eerie resemblance to a rape that had taken place months earlier in a nearby town. Joining forces with the detective on that case, Edna Hendershot, the two soon discovered they were dealing with a serial rapist. As their investigation deepened, it became clear that numerous police departments had extremely similar cases on their hands – and that Marie\'s story bore an eerie resemblance to the cases they were investigating.', '300.00', 26, 26, 7),
('1787461483', 'The Family Upstairs', 'Lisa Jewell', 'The Family Upstairs.jpg', 'Two entangled families.\r\nA house with the darkest of secrets.\r\nA compulsive thriller from Lisa Jewell.', '343.00', 17, 16, 3),
('1935209809', 'Planting the seeds', 'Nishant K Baxi', 'planting a sids.jpg', 'Practicing Mindfulness with Children is the fruit of decades of development and innovation in the Plum Village community\'s collective practice with children. Based on Thich Nhat Hanh\'s thirty years of teaching mindfulness and compassion to parents, teachers, and children, the book and enclosed CD cover a wide range of contemplative and fun activities parents and educators can do with their children or students. The activities are designed to help relieve stress, increase concentration, nourish gratitude and confidence, deal with difficult emotions, touch our interconnection with nature, and improve communication. \r\n\r\nPlanting Seeds offers insight, concrete activities, and curricula that parents and educators can apply in school settings, in their local communities or at home, in a way that is meaningful and inviting to children. The key practices presented include mindful breathing and walking, inviting the bell, pebble meditation, the Two Promises or ethical guidelines for children, children\'s versions of Touching the Earth and Deep Relaxation, eating meditation and dealing with conflict and strong emotions. Also included, are the lyrics to the songs on the enclosed CD that summarize and highlight the key teachings, as well as a chapter on dealing effectively with conflict in the classroom or difficult group dynamics, based on a conference with Thich Nhat Hanh, teachers and students.', '200.00', 22, 22, 5),
('1949798089', 'Dear you', 'Derra Nicole Sabo', 'Dear you.jpg', 'Derra Sabo shares a bit of her world with you in this delightful memoir filled with \"letters\" to family and friends. Overcoming challenges by simply living life; Derra shares her experiences here in hopes of helping the reader gain an appreciation for life as it happens.', '850.00', 29, 29, 9),
('386989275', 'STOP WISHING START CREATING', 'Gertrude Marie', 'Stop wishing start cresting.jpg', 'In Stop Wishing Start Creating, author Gertrude Marie draws on 15 years of personal and corporate instruction, helping thousands of people to harness the powers of the Law of Attraction, Manifesting, Hypnotherapy and Guided Meditations to offer you a proven and powerful 7-step blueprint that anybody can use to create the life of their dreams.\r\n\r\nStop Wishing; Start Creating starts where The Secret Abraham Hicks and manifestation books like The Frequency leave off, by giving readers easy-to-understand guidance on how to manifest happiness, love and attract their dream life. Learn how to power up your energy and bring it to a higher frequency where the Law of Attraction will work for you, manifesting a reality beyond your wildest dreams. This life-changing Law of Attraction book takes your understanding to another level by outlining an easy to follow manifestation code with ‘Seven Attractor Steps.’ It includes fun ‘Let’s Play’ exercises that can work as a Law of Attraction journal allowing you to achieve a high frequency and attune your energy to whatever you want to manifest, so you can attract it to your life easier and faster. As you attune your thoughts, words, feelings and frequency to your Higher Purpose and that which you want to manifest, you become a magnet of good things; you start attracting prosperity, love, happiness, success, and miracles, and can even help you overcome limitations like shyness, anxiety or low self-esteem.', '500.00', 32, 32, 10),
('8185301417 ', 'Swami Vivekananda A Biography', 'Swami Nikhilananda', 'Swami Vivekananda A Biography.jpg', 'Herein the readers will find his life described in a short compass, without sacrificing the essential details. This is a masterly presentation of his life from the pen of a scholar of repute. A worthy book for all those who want to study Vivekananda in brief without loosing the crucial aspects of his life. Ever since it was first published in the year 1964 it has undergone twenty four re-prints..such is the popularity of the book.', '150.00', 19, 18, 4),
('9353570840', 'Yoga Mythology: 64 Asanas and Their Stories', 'Matthew Rulli', 'YOGA MYTHOLOGY.jpg', 'The popular names of many yogic asanas from Virbhadra-asana and Hanuman-asana to Matsyendra asana, Kurma asana and Ananta asana are based on characters and personages from Indian mythology. Who were these mythological characters, what were their stories, and how are they connected to yogic postures? Devdutt Pattanaik is newest book Yoga Mythology (co-written with international yoga practitioner Matt Rulli) retells the fascinating tales from Hindu, Buddhist and Jain lore that lie behind the yogic asanas the world knows so well . in the process he draws attention to an Indic worldview based on the concepts of eternity, rebirth, liberation and empathy that has nurtured yoga for thousands of years.', '278.00', 11, 10, 1),
('9384315028', 'Once apon a time', 'Patrick Fischler', 'once opon a time 3.jpg', '“Quartet of the Town” by Trippayar Sahasranaman Priyaa Bassanio vows to make the aristocrats of London pay dearly for the peace they took away from his family. He unfolds the loopholes in the prevalent system of insurance (bottomry) and architects a plan to swindle money from his rivals. Yet, fate has something different in store for all of them… “The Treasure of Gods” by Karthik C In the story \"The Treasure of Gods\", the author takes you on a quest to find the divine gold which brings out virtues from outlaws and vices from Kings. A tale of destiny causing the rise and fall of Kingdoms will no doubt alter history, for better or for worse. “The Woman of the Night” by Dr Roshan Radhakrishnan When the young Prince begins to assert his rule upon his countrymen, he is hailed as a worthy successor to the throne. However, from within the palace, various plans have been set in motion to destroy the Prince’s resolve… plans that all lead to the doorstep of a young prostitute. “The Black Secrets of the White Dream” by Aarush Deora It takes only one man to alter history - one man whose decision will affect what generations of mankind shall come to believe. The fate of the world\'s most beloved monument - the Taj - had once rested with one man - Holden Gatsby, an ordinary professor. So what had happened when he found himself in a hostile city with the key to the black secret of the white dream?', '150.00', 21, 21, 5),
('9387022390', 'A Girl to Remember', 'Ajay K Pandey', 'A Girl to Remember.jpg', 'In every angel a demon hides, And in every demon, an angel strides. Neel is a self-proclaimed demon, a slave to his desires, putting at stake even the purest of relationships for it. He lives for himself, takes life as it comes, and considers people who love as emotional fools. When he first sets his eyes on his new landlady, a widow who is eleven years elder to him, all he can see is an opportunity. He has a plan to get rich and is working hard to achieve it, until he bumps into Pihu. She is an immature teenager who likes Neel for no apparent reason, and blindly believes that he is an angel who will take away all her life’s troubles. Neel hates Pihu for her unexplained obsession, and her being a hindrance in his plan, but her firm resolve to see a good person in him shakes Neel to the core. Will Pihu make a difference? Does inner transformation come to a man who has gone to a point of no return? A Girl to Remember is an emotional roller coaster which will make you believe that confession is the best punishment.', '151.00', 15, 14, 2),
('9387067556', 'World History', 'Krishna Reddy', 'World History.jpg', 'McGraw Hill Education is proud to present ?World History? by their bestselling author Krishna Reddy who has written ?Indian History?. Meant for the Civil Services Main Examination this book on ?World History? presents the events of world history in a chronological manner. The discussions on the topics are panoramic, they discuss the topic from all possible angles which answer questions like, what happened? when did it happen? and how did it happen? and what was the outcome? These discussions will help the students thoroughly understand the subject and develop a perspective.', '350.00', 25, 25, 7),
('9388810376', 'Worlds Greatest Entrepreneurs: Biographies of Inspirational ', 'Wonder House Books', 'World greatest.jpg', 'A meticulously researched book, which celebrates the achievements of famous and intriguing entrepreneurs who have inspired generations with their talent, hard work and success stories. Age appropriate content, fun facts and bold illustrations will appeal to the curiosity of young inquisitive minds and help them develop their reading skills and General Knowledge.', '180.00', 20, 19, 4),
('978-1-118-94924-5', 'Programmable Logic Controllers', 'Dag H. Hanssen', 'logic_program.jpg', 'Widely used across industrial and manufacturing automation, Programmable Logic Controllers (PLCs) perform a broad range of electromechanical tasks with multiple input and output arrangements, designed specifically to cope in severe environmental conditions such as automotive and chemical plants.Programmable Logic Controllers: A Practical Approach using CoDeSys is a hands-on guide to rapidly gain proficiency in the development and operation of PLCs based on the IEC 61131-3 standard. Using the freely-available* software tool CoDeSys, which is widely used in industrial design automation projects, the author takes a highly practical approach to PLC design using real-world examples. The design tool, CoDeSys, also features a built in simulator / soft PLC enabling the reader to undertake exercises and test the examples.', '299.00', 2, 2, 11),
('978-1-1180-2669-4', 'Professional JavaScript for Web Developers, 3rd Edition', 'Nicholas C. Zakas', 'pro_js.jpg', 'If you want to achieve JavaScript is full potential, it is critical to understand it is nature, history, and limitations. To that end, this updated version of the bestseller by veteran author and JavaScript guru Nicholas C. Zakas covers JavaScript from its very beginning to the present-day incarnations including the DOM, Ajax, and HTML5. Zakas shows you how to extend this powerful language to meet specific needs and create dynamic user interfaces for the web that blur the line between desktop and internet. By the end of the book, you will have a strong understanding of the significant advances in web development as they relate to JavaScript so that you can apply them to your next website.', '360.00', 1, 1, 11),
('978-1-4571-0402-2', 'Professional ASP.NET 4 in C# and VB', 'Scott Hanselman', 'pro_asp4.jpg', 'ASP.NET is about making you as productive as possible when building fast and secure web applications. Each release of ASP.NET gets better and removes a lot of the tedious code that you previously needed to put in place, making common ASP.NET tasks easier. With this book, an unparalleled team of authors walks you through the full breadth of ASP.NET and the new and exciting capabilities of ASP.NET 4. The authors also show you how to maximize the abundance of features that ASP.NET offers to make your development process smoother and more efficient.', '295.00', 1, 1, 11),
('978-1-484216-40-8', 'Android Studio New Media Fundamentals', 'Wallace Jackson', 'android_studio.jpg', 'Android Studio New Media Fundamentals is a new media primer covering concepts central to multimedia production for Android including digital imagery, digital audio, digital video, digital illustration and 3D, using open source software packages such as GIMP, Audacity, Blender, and Inkscape. These professional software packages are used for this book because they are free for commercial use. The book builds on the foundational concepts of raster, vector, and waveform (audio), and gets more advanced as chapters progress, covering what new media assets are best for use with Android Studio as well as key factors regarding the data footprint optimization work process and why new media content and new media data optimization is so important.', '375.00', 4, 4, 11),
('978-8194894940', 'Being an Indian Teenager', 'Muskan Jha', 'Being an Indian Teenager.jpg', 'In today\'s world being a teenager is not really easy. There are different challenges that we have to face, decisions to make and roads to take. The people and the environment around us greatly affect the way we think and act as teenagers. Being a teenager can be hard but at the same time, it is fun. We daily face new experiences. At this point in our lives, we feel like we are neither children anymore nor really grown-ups too. Teenage as we all know is one of the most important and memorable period of a person\'s life. This is the period during which we face and feel a lot of things ranging from our changing physical appearance, increasing body weight, parents constantly comparing us to our friends and relatives, peer pressure, anxiety, depression, suicidal thoughts and much more for the first time. \'Being an Indian Teenager\' is an anthology containing stories, poems and articles from some established and some new writers. They have tried their best to portray every feeling and emotion that they have faced as Indian teenagers.', '260.00', 12, 11, 2),
('9780349140438', 'Steve Job The Exclusive Biography', 'Walter Isaacson', 'Steve Job The Exclusive Biography.jpg', 'Based on more than forty interviews with Steve Jobs conducted over two years - as well as interviews with more than a hundred family members, friends, adversaries, , and colleagues - this is the acclaimed, internationally bestselling biography of the ultimate icon of inventiveness.\r\n\r\nWalter Isaacson tells the story of the rollercoaster life and searingly intense personality of creative entrepreneur whose passion for perfection and ferocious drive revolutionized six industries: personal computers, animated movies,music, phones, tablet computing, and digital publishing.\r\n\r\nAlthough Jobs cooperated with this book, he asked for no control over what was written, nor even the right to read it before it was published. He put nothing off limits. He encouraged the people he knew to speak honestly. And Jobs speaks candidly, sometimes brutally so, about the people he worked with and competed against. His friends, foes, and colleagues provide an unvarnished view of the passions, perfectionism, obsessions, artistry, devilry, and compulsion for control that shaped his approach to business and the innovative products that resulted.', '200.00', 13, 20, 4),
('9788183225090', 'Believe in Yourself', 'Dr. Joseph Murphy', 'Believe in Yourself.webp', 'In Believe in Yourself, Dr. Murphy stresses about having faith in ones abilities, believing in the inner self and in having the courage to chase your dream, come what may. The book was first published in 1955 but remains as popular as it was then. Being a preacher, with decades of experience behind him, Dr Murphy delves into lives of people to demonstrate the all encompassing power of self. By citing interesting episodes from the lives of artists, writers, entrepreneurs and ordinary people, who achieved acclaim and success, the author goes on to emphasize that one thread that runs through was a strong belief in oneself. The book has proved highly motivational and has enabled many readers to overcome low self esteem and achieve their objectives in life. The author points out various ways by which one can overcome defeat, hardships and keep on the righteous track to succeed by using only fair means. People who are low in confidence, need a direction in life or a guiding light to keep them motivated makes this subjective compulsion a key to success for any individual says the author.', '100.00', 13, 12, 2),
('9789381576052', 'ASURA Tale of the Vanquished', 'Anand Neelakantan', 'ASURA Tale of the Vanquished.png', 'he story of the Ramayana had been told innumerable times. The enthralling story of Rama, the incarnation of God, who slew Ravana, the evil demon of darkness, is known to every Indian. And in the pages of history, as always, it is the version told by the victors, that lives on. The voice of the vanquished remains lost in silence. But what if Ravana and his people had a different story to tell? The story of the Ravanayana had never been told.', '273.00', 9, 9, 1),
('979-8768752668', 'Made to impress', 'Umair Riaz', 'Made to impress.jpg', 'She had been circumnavigating the parlour for 30 minutes. She was wearing a straight forward yellow shirt with white pant and white shoes. Four individuals were watching him turn left and right, out of which Emma and Anna had come to a couple of times, yet Steven and Frank looked somewhat energetic. It appeared as though Jordan\'s class ... albeit these individuals knew very well that this class would just keep going for two minutes in light of the fact that the sooner Paul blew up with Sendra, the sooner Sendra would befuddle him in the most natural-sounding way for him and assemble compassion. Used to come\r\nStop ...\r\nAt the command of the light, individuals who had recently left the furrow were stunned and irately gazed at the clock.\r\nToday we won\'t pardon them, they have rung the chime however they know nothing about it. We ask what they do outside when a large portion of the city is sleeping.', '500.00', 29, 33, 10);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(5) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'MYTH'),
(2, 'NOVEL'),
(3, 'FICTION'),
(4, 'BIOGRAPHY'),
(5, 'FAIRLY-TAIL'),
(6, 'DRAMA'),
(7, 'HISTORY'),
(8, 'WESTERN'),
(9, 'POEMS'),
(10, 'NON-FICTION'),
(11, 'ENGINEERING');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `description`) VALUES
(1, 'Bhavin kansagara', 'kbm4995@gmail.com', 'this website is very easy to use.'),
(3, 'Nakum Punit', 'nakumpunit2002@gmail.com', 'i can not travel for books. i just order books online, and that save my time also.'),
(5, 'Arzu zalavadiya', 'arzu01@gmail.com', 'i am happy with this book website. Categories are good for searching books. '),
(6, 'Isha bhalodiya', 'ishabhalodiya01@gmail.com', 'i can buy books in stand alone place. that save my time.');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerid` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(80) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `zip_code` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `country` varchar(60) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `name`, `address`, `city`, `zip_code`, `country`) VALUES
(9, '', '', '', '', ''),
(10, 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(11, 'Nakum Punit', 'nakumpunit2002@gmail.com', 'junagadh', '362037', 'India'),
(12, 'arzu', 'arzu!23@gmail.com', 'Junagadh', '360987', 'india'),
(13, 'isha', '', '', '', ''),
(14, 'princeeeee', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `customerid` int(10) UNSIGNED NOT NULL,
  `amount` decimal(6,2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ship_name` char(60) COLLATE latin1_general_ci NOT NULL,
  `ship_address` char(80) COLLATE latin1_general_ci NOT NULL,
  `ship_city` char(30) COLLATE latin1_general_ci NOT NULL,
  `ship_zip_code` char(10) COLLATE latin1_general_ci NOT NULL,
  `ship_country` char(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `customerid`, `amount`, `date`, `ship_name`, `ship_address`, `ship_city`, `ship_zip_code`, `ship_country`) VALUES
(18, 9, '500.00', '2022-03-11 02:35:24', '', '', '', '', ''),
(19, 10, '155.00', '2022-03-11 02:58:11', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(20, 10, '635.00', '2022-03-11 03:00:22', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(24, 9, '310.00', '2022-03-11 03:12:51', '', '', '', '', ''),
(25, 10, '350.00', '2022-03-11 03:13:25', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(26, 10, '700.00', '2022-03-11 03:15:51', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(32, 10, '360.00', '2022-03-11 03:41:29', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(33, 10, '1000.00', '2022-03-11 03:48:13', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(34, 10, '480.00', '2022-03-11 03:58:10', 'Nakum Punit', 'shree swaminarayan gurukul gyanbag', 'junagadh', '362037', 'India'),
(35, 11, '295.00', '2022-03-20 10:32:57', 'Nakum Punit', 'nakumpunit2002@gmail.com', 'junagadh', '362037', 'India'),
(36, 12, '677.00', '2022-05-12 14:21:03', 'arzu', 'arzu!23@gmail.com', 'Junagadh', '360987', 'india'),
(37, 13, '343.00', '2022-05-12 14:41:29', 'isha', '', '', '', ''),
(38, 9, '0.00', '2022-05-12 14:41:30', '', '', '', '', ''),
(39, 14, '100.00', '2022-05-12 14:42:50', 'princeeeee', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `book_isbn` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `item_price` decimal(6,2) NOT NULL,
  `quantity` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`orderid`, `book_isbn`, `item_price`, `quantity`) VALUES
(1, '978-1-118-94924-5', '20.00', 1),
(1, '978-1-44937-019-0', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(2, '978-1-118-94924-5', '20.00', 1),
(2, '978-1-44937-019-0', '20.00', 1),
(2, '978-1-49192-706-9', '20.00', 1),
(3, '978-0-321-94786-4', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(5, '978-1-484217-26-9', '480.00', 1),
(6, '978-0-7303-1484-4', '350.00', 1),
(7, '545464', '0.00', 1),
(7, '978-0-321-94786-4', '500.00', 3),
(7, '978-1-49192-706-9', '650.00', 1),
(7, '978-1-484216-40-8', '375.00', 1),
(7, '978-0-7303-1484-4', '350.00', 1),
(7, '9789381576052', '273.00', 1),
(7, '978-1-4571-0402-2', '295.00', 1),
(10, '978-0-321-94786-4', '500.00', 1),
(10, '978-0-7303-1484-4', '350.00', 1),
(10, '978-0-321-94786-4', '500.00', 1),
(10, '978-0-321-94786-4', '500.00', 1),
(10, '123456', '155.00', 1),
(10, '123456', '155.00', 1),
(10, '123456', '155.00', 1),
(16, '123456', '155.00', 1),
(16, '978-0-7303-1484-4', '350.00', 1),
(17, '978-1-484217-26-9', '480.00', 1),
(17, '978-0-321-94786-4', '500.00', 1),
(19, '123456', '155.00', 1),
(19, '123456', '155.00', 1),
(19, '978-1-484217-26-9', '480.00', 1),
(17, '978-1-484216-40-8', '375.00', 2),
(17, '978-0-7303-1484-4', '350.00', 1),
(17, '978-1-44937-019-0', '399.00', 1),
(17, '123456', '155.00', 2),
(19, '978-0-7303-1484-4', '350.00', 1),
(19, '978-0-7303-1484-4', '350.00', 2),
(17, '978-0-321-94786-4', '500.00', 1),
(17, '978-1-44937-075-6', '480.00', 1),
(17, '123456', '155.00', 1),
(17, '978-0-7303-1484-4', '350.00', 1),
(17, '0143423320', '217.00', 2),
(19, '978-1-1180-2669-4', '360.00', 1),
(19, '978-0-321-94786-4', '500.00', 2),
(19, '978-1-44937-075-6', '480.00', 1),
(35, '978-1-4571-0402-2', '295.00', 1),
(36, '0143423320', '217.00', 1),
(36, '1499748949', '230.00', 2),
(37, '1787461483', '343.00', 1),
(39, '9788183225090', '100.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `publisherid` int(10) UNSIGNED NOT NULL,
  `publisher_name` varchar(60) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisherid`, `publisher_name`) VALUES
(1, 'Wroo'),
(2, 'Wiley'),
(3, 'O\'Reilly Media'),
(4, 'Apress'),
(5, 'Packt Publishing'),
(6, 'Addison-Wesley'),
(8, 'Penguin Books India'),
(9, 'Speaking Tree'),
(11, 'Devdutt Pattanaik'),
(12, 'Literatureslight'),
(13, 'Simon & Schuster'),
(14, 'Westland publications'),
(15, 'Sristhi Publishers & Distributors'),
(16, 'The Silent Patient: The record-breaking'),
(17, 'Simon & Schuster.'),
(18, 'Independently'),
(19, 'ADVAITA ASHRAMA'),
(20, 'Wonder House'),
(21, 'Fablery'),
(22, 'Parallax Press'),
(23, 'CreateSpace'),
(24, 'Ballantine Books'),
(25, 'McGraw Hill Education'),
(26, 'Windmill Books'),
(27, 'Ulverscroft'),
(28, 'Thorndike Pr'),
(29, 'Independently Published'),
(30, 'Revival'),
(31, 'MIT Press'),
(32, 'Zeleste'),
(33, 'published independently'),
(34, 'Golden/Disney');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(14, 'punit', 'nakumpunit2002@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(15, 'isha', 'nakum2002@gmail.com', 'e034fb6b66aacc1d48f445ddfb08da98'),
(16, 'isha', 'ishabhalodiya01@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`,`pass`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`authorid`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_isbn`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`publisherid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `authorid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customerid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `publisherid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
