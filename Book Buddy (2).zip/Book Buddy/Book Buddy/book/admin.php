<?php
	$title = "Administration section";
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Admin Login</title>
</head>
<body>
<div class="container">

	<form method="post" class="login-email" action="admin_verify.php">
	<p class="login-text" style="font-size: 2rem; font-weight: 800;">Admin Login</p>
		<div class="input-group">
			<div class="col-md-4">
				<input type="text"placeholder="Name" name="name" class="form-control">
			</div>
		</div>
		<div class="input-group">
			<div class="col-md-4">
				<input type="password" placeholder="Password" name="pass" class="form-control">
			</div>
		</div>
		
		<div class="input-group">
				<button type="submit" name="submit" class="btn btn-primary ">Submit</button>
			</div>
		
	</form>

<?php

?>