<?php
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	
?>  
<?php
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Reset Password</title>
</head>
<body>
<div class="container">
<form method="post" class="login-email" action="changepass.php">
		
<p class="login-text" style="font-size: 2rem; font-weight: 800;">Change Password</p>
  
    <div class="input-group">
        <input type="text" placeholder="Email" name="email"  id="email" title="Email">
    </div>
	<div class="input-group">
        <input type="password" placeholder="New Password" id="newPassword" name="newPassword" title="New password" />
    </div>   
    <div class="input-group">  
        <input type="password" placeholder="Conform Password" id="confirmPassword" name="confirmPassword" title="Confirm new password" />
     </div>    
     <div class="input-group">
				<button type="submit" value="Change Password" name="submit" title="Change password" class="btn">Change Password</button>
			</div>
</div>
    </form>
<?php
	mysqli_close($conn);
	
?>